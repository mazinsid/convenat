@extends('layouts.header')


<meta name="csrf-token" content="{{ csrf_token() }}" />

<style>
        dialog[open] {
        animation: appear .15s cubic-bezier(0, 1.8, 1, 1.8);
      }
      
        dialog::backdrop {
          background: linear-gradient(45deg, rgba(0, 0, 0, 0.5), rgba(54, 54, 54, 0.5));
          backdrop-filter: blur(3px);
        }
        
       
      @keyframes appear {
        from {
          opacity: 0;
          transform: translateX(-3rem);
        }
      
        to {
          opacity: 1;
          transform: translateX(0);
        }
      } 
      </style>
@section('content')
<main class="sm:container sm:mx-auto sm:mt-10">
    <div class="w-full sm:px-6">

        @if (session('status'))
            <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4" role="alert">
                {{ session('status') }}
            </div>
        @endif
    </div>
    <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
            أضافة عهدة    
            </header>
            <div class="flex w-full h-auto py-10 px-2 justify-center items-center bg-gray-200 rounded text-center text-gray-500">
                    <div class="m-7">
                      <form action="{{route('covenant_store')}}" method="POST">
                          @csrf
                          <div class="m-7">
                              <div class="mb-6">
                                      <div class="inline-block relative w-64">
                                          <select name="regionsinsert" id="regions"
                                          class="block appearance-none w-full bg-white border border-gray-400
                                           hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                           focus:shadow-outline">
                                            <option>أختار {{__('tables.regions')}}</option>
                                            @foreach ($regions as $region )
                                            <option value="{{$region->id}}">{{$region->name}}</option>
                                            @endforeach
                                          </select>
                                      </div>
                                  </div>
                                  <div class="mb-6">
                                          <div class="inline-block relative w-64">
                                                  <select name="citiesinsert" id="cities"
                                                  class="block appearance-none w-full bg-white border border-gray-400
                                                   hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                                   focus:shadow-outline">
                                                 

                                                  </select>
                                      </div>
                                  </div>
                                  <div class="mb-6">
                                          <div id="branchesload" class="block relative w-64">
                                                  <select name="branch_idinsert" id="Branches"
                                                  class="block appearance-none w-full bg-white border border-gray-400
                                                   hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                                   focus:shadow-outline">
                                                 

                                                  </select>
                                          </div>
                                      </div>
                                      <div class="mb-6">
                                              <div class="inline-block relative w-64">
                                                  <select name="employees_id" id="employees"
                                                  class="block appearance-none w-full bg-white border border-gray-400
                                                   hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                                   focus:shadow-outline">
                                              
                                                  
                                                  </select>
                                              </div>
                                          </div>
                            {{-- product --}}
                            <div class="mb-6">
                                <div class="inline-block relative w-64">
                                    <select name="product_id" id="product"
                                    class="block appearance-none w-full bg-white border border-gray-400
                                     hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                     focus:shadow-outline">
                                      <option>أختار {{__('tables.product')}}</option>
                                      @foreach ($products as $product )
                                      <option value="{{$product->id}}">{{$product->name}}</option>
                     
                                      @endforeach
                                    
                                    </select> 
                                
                                </div>
                                </div>
                                <div class="mb-6">
                                    <div  class="inline-block relative w-64">
                                            <select name="pmodels" id="pmodel"
                                            class="block appearance-none w-full bg-white border border-gray-400
                                             hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                             focus:shadow-outline">
                                            </select>
                                    </div>
                                    
                                </div>
                                <div class="mb-6">
                                        <div  class="inline-block relative w-64">
                                                <select name="ptypes_id" id="ptype"
                                                class="block appearance-none w-full bg-white border border-gray-400
                                                 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                                 focus:shadow-outline">
                                                </select>
                                        </div>
                                        
                                    </div>
                                    <div  id="car" style="display: none" >
                                    <div class="mb-6">
                                        <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400">{{__('tables.plate_number')}}</label>
                                        <input   type="text" name="plate_number" id="acceptance" placeholder="John Doe"  class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                                    </div>
                                    <div class="mb-6">
                                        <label  for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400">{{__('tables.vehicle_type')}}</label>
                                        <input   type="text" name="vehicle_type" id="acceptance" placeholder="John Doe"  class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                                    </div>
                                        
                                    </div>
                      <div class="mb-6">
                        <div class="inline-block relative w-64">
                            <select name="serials_id" id="serials"
                            class="block appearance-none w-full bg-white border border-gray-400
                             hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                             focus:shadow-outline">
                             
                            
                            </select>
                        </div>
                    </div>
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400">{{__('tables.acceptance')}}</label>
                                <input  type="date" name="acceptance" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                            </div>
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400">{{__('tables.code')}}</label>
                                <input  type="text" name="code_number" id="acceptance" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                            </div>
                           
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400">{{__('tables.note')}}</label>
                                <textarea  type="text" name="note" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" >
                              
                                </textarea>
                            </div>
                            <div class="mb-6">
                                <button type="submit" class=" btn-submit w-full px-3 py-4 text-white bg-indigo-500 rounded-md focus:bg-indigo-600 focus:outline-none">{{__('button.add')}}</button>
                            </div>
                            <p class="text-base text-center text-gray-400" id="result">
                            </p>
                      </form>
                    </div>

           </div>
           
    </section>
</main>
<script type="text/javascript">

  /* Load cities into postion <selec> */
$( "#regions" ).change(function() 
{
  select = '<option > اختار المدينة</option>'
$.getJSON("/covenant/public/employee/"+ $(this).val() +"/getCities", function(jsonData){
  $.each(jsonData, function(i,data)
  {

       select +='<option value="'+data.id+'">'+data.name+'</option>';
   });
select += '</select>';
$("#cities").html(select);
});
});

    /* Load branches into postion <selec> */
$( "#cities" ).change(function() 
{
  select = '<option > اختار الفروع</option>'
$.getJSON("/covenant/public/employee/"+ $(this).val() +"/getBranche", function(jsonData){
  $.each(jsonData, function(i,data)
  {

       select +='<option value="'+data.id+'">'+data.name+'</option>';
   });
select += '</select>';
$("#Branches").html(select);
});
});

$( "#Branches" ).change(function() 
{
  select = '<option > اختار اسم المستخدم</option>'
$.getJSON("/covenant/public/employee/"+ $(this).val() +"/getEmployee", function(jsonData){
  $.each(jsonData, function(i,data)
  {

       select +='<option value="'+data.id+'">'+data.name+'</option>';
   });
select += '</select>';
$("#employees").html(select);
});
});
</script>

{{-- load select sirale product --}}
<script type="text/javascript">

  /* Load getModle into option <selec> */
$( "#product" ).change(function() 
{
$.getJSON("/covenant/public/serial/"+ $(this).val() +"/getModle", function(jsonData){
select = '<option >أختار موديلات الأجهزة</option>';
  $.each(jsonData, function(i,data)
  {

       select +='<option value="'+data.id+'">'+data.name+'</option>';
   });
select += '</select>';
$("#pmodel").html(select);
});
});

    /* Load ptype into option <selec> */
$( "#pmodel" ).change(function() 
{
$.getJSON("/covenant/public/serial/"+ $(this).val()+"/getType", function(jsonData){
select = '<option  >أختار النوع</option>';
  $.each(jsonData, function(i,data)
  {
       select +='<option value="'+data.id+'">'+data.name+'</option>';
   });
select += '</select>';
$("#ptype").html(select);
});
});

$( "#ptype" ).change(function() 
{
$.getJSON("/covenant/public/serial/"+ $(this).val()+"/getSerial", function(jsonData){
select = '<option  >أختار الرقم الجهاز</option>';
  $.each(jsonData, function(i,data)
  {
       select +='<option value="'+data.id+'">'+data.serial+'</option>';
   });
select += '</select>';
$("#serials").html(select);
});
});
   /* Load ptype into option <selec> */
  $( "#ptype" ).change(function() 
{
if ( $("#ptype").val() == 1) {
  document.getElementById('car').style.display= "inline" ;
}else{
  document.getElementById('car').style.display= "none" ;
}
});

</script>
@endsection