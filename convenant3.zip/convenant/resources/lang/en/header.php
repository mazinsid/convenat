<?php

return [

    'home' => 'الرئسية',
    'cities' => 'المدن',
];
