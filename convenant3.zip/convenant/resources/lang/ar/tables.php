<?php

return [

    'code' => 'الكود',
    'name' => 'الاسم',
    'phone' => 'رقم الهاتف',
    'location' => 'الموقع',
    'email' => 'البريد الالكتروني',
    'role' => 'صلاحيات',
    'password' => 'كلمة المرور',
    'national_id' => 'الرقم الوطني',
    'gender' => 'النوع',
    'vendor' => 'بائع',
    'category' => 'التصنيف',
    'status' => 'الحالة',
    'acceptance' => 'قبول',
    'note' => 'ملاحظة',
    'plate_number' => 'لوحة السيارة',
    'vehicle_type' => 'نوع السيارة',
    'return' => 'تاريخ ارجاع',
    
    'covenant' => 'العهد',
    'serial' => 'الرقم المتسلسل',
    'type' => 'نوع',
    'product' => 'الجهاز',
    'model' => 'الموديل',
    'job' => 'الوظيفة',
    'rank' => 'الرتبة',
    'regions' => 'المناطق',
    'cities' => 'المدن',
  'branch' => 'الفرع',
  'department' => 'الادارة',
  //
  'circle number' => 'رقم الدائرة',
  'circle type' => 'نوع الدائرة',
  'circle speed' => 'سرعة الدائرة',
  'cable number' => 'رقم الكابل',
  'expiry' => 'تاريخ الانتهاء',
  'faults_date' => 'تاريخ العطل',
  'fixed_date' => 'تاريخ الصيانة',
  'reason' => 'السبب',
  

];
