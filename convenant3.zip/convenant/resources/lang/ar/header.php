<?php

return [

    'home' => 'الرئسية',
    'covenant' => 'العهد',
    'cities' => 'المدن',
   
    'regions' => 'المناطق',
    'department' => 'الأدارات',
    'branch' => 'فرع',
    'rank' => 'رتبة',
    'job' => 'المسمي الوظيفي',
    'employee' => 'الموظف',
    'categores' => 'الاصناف',
    'product' => 'الجهاز',
    'model' => 'الموديل',
    'type' => 'نوع',
    'accessory' => 'الملحقات',
    'serial' => 'الرقم المتسلسل',
    'users' => 'ألمستخدمين',
    'landline convenant' => 'العهد السلكية',
    'return' => 'ارجاع',
    //  

    'provider' => 'مزود الخدمة',
    'wired' => 'الأجهزة السلكية',
    'simcard' => 'شرائح هاتف',
    'landline' => 'خط أرضي',
    // 
    'report' => 'التقارير',
    'report convent' => 'العهد الاجهزة اللاسلكية',
    'report leadline' => 'العهد الاجهزة السلكية',
    'report status' => 'الجهزة المتوفر',
    'report sirale' => 'جهزة محدد',
    'report employee' => 'موظف محدد',
    'fault' => 'ألاعطال',
];
