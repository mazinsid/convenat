<?php

return [

    'code' => 'الكود',
    'name' => 'الاسم',
    'phone' => 'رقم الهاتف',
    'location' => 'الموقع',
  
];
