<?php

return [

    'add' => 'أضافة',
    'edit' => 'تعديل',
    'reomve' => 'حذف',
    'control' => 'تحكم',
    'accessory' => 'ملحقات',
    'search' => 'يحث',
    'print' => 'طباعة',
    'detelis' => 'تفاصيل',

];
