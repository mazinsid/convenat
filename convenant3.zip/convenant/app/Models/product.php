<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    use HasFactory;
    protected $fillable = [
        'vendor',
        'name',
        'product_categories_id',
    ];
    public function category()
    {
        return $this->belongsTo(product_category::class , 'product_categories_id');
    }
    public function pmodel()
    {
        return $this->hasMany(pmodel::class);
    }
}
