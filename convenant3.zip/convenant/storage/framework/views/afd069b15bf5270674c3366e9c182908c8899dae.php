<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto sm:mt-10">

    <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <div class="bg-white shadow p-4 flex">
                        <span class="w-auto flex justify-end items-center text-gray-500 p-2">
                            <i class="material-icons text-3xl">     
                                <a id="btn" class="py-3 px-10 bg-gray-800 text-white 
                                rounded text shadow-xl"><?php echo e(__('button.print')); ?></a>
                            </i>
                        </span>
                        
                        من     <input type="date" name="start">
                        الي     <input type="date" name="end">
                        <button type="submit" id="btsearch" class="btsearch py-3 px-10 bg-gray-800 text-white 
                        rounded text shadow-xl">بحث</button>
                    </div>

                </header>

    
    <div class="w-full p-6">
        <table class="border-collapse w-full">
            <thead>
                <tr>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('header.employee')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('header.rank')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.type')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.serial')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.acceptance')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.code')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.note')); ?></th>
         </tr>
            </thead>
            <tbody id="tbody">

                
            <?php $__currentLoopData = $covenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $covenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
                <tr class="bg-white lg:hover:bg-gray-100 flex lg:table-row flex-row lg:flex-row flex-wrap lg:flex-no-wrap mb-10 lg:mb-0">
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->employee->name); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->employee->rank->name); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->ptype->name); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->serial->serial); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->acceptance); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->code_number); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                            <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                           <?php echo e($covenant->note); ?>

                        </td>
                   
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
        </table>
        <!-- component -->
    </div>
    
    </section>
</main>






<script type="text/javascript">

    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        $("#btsearch").click(function(e){
    
            e.preventDefault();

            var start = $("input[name=start]").val();
            var end = $("input[name=end]").val();
            var url = '<?php echo e(url('report/SearchConventDate')); ?>';
    
            $.ajax({
               url:url,
               method:'POST',
               datatype: false,
               data:{
                start:start, 
                end:end, 
                    },
               success:function(response){
              
                $('#tbody').html(response);
                  
               },
               error:function(error){
                  console.log(error)
               }
            });
        });
  

    </script>

    
    <?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mazin/laravel/convenant/resources/views/report/convent.blade.php ENDPATH**/ ?>