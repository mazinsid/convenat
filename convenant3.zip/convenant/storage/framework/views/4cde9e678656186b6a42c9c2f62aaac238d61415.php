<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto sm:mt-10">

    <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <div class="bg-white shadow p-4 flex">
                        <span class="w-auto flex justify-end items-center text-gray-500 p-2">
                            <i class="material-icons text-3xl">     
                                <a id="btn" class="py-3 px-10 bg-gray-800 text-white 
                                rounded text shadow-xl"><?php echo e(__('button.print')); ?></a>
                            </i>
                        </span>
                        <div class=" w-64">
                            <select name="regionsinsert" id="regions"
                            class="block appearance-none w-full bg-white border border-gray-400
                             hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                             focus:shadow-outline">
                              <option>أختار <?php echo e(__('tables.regions')); ?></option>
                              <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                            <div class=" w-64">
                                    <select name="citiesinsert" id="cities"
                                    class="block appearance-none w-full bg-white border border-gray-400
                                     hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                     focus:shadow-outline">
                                   

                                    </select>
                        </div>
                            <div id="branchesload" class="w-64">
                                    <select name="branch_id" id="Branches"
                                    class="block appearance-none w-full bg-white border border-gray-400
                                     hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                     focus:shadow-outline">
                                   

                                    </select>
                            </div>
                            <div id="employeeload" class="w-64">
                                <select name="employees" id="employees"
                                class="block appearance-none w-full bg-white border border-gray-400
                                 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none 
                                 focus:shadow-outline">
                               

                                </select>
                        </div>
                        <button type="submit" id="btsearch" class="btsearch py-3 px-10 bg-gray-800 text-white 
                        rounded text shadow-xl">بحث</button>
                    </div>

                </header>

    
    <div class="w-full p-6">
        <table class="border-collapse w-full">
            <thead>
                <tr>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('header.serial')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.type')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('كود الاستلام ')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('تاريخ الاستلام')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('ملاحظة')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('تاريخ الارجاع')); ?></th>  </tr>
            </thead>
            <tbody id="tbody">

                
            </tbody>
        </table>
        <!-- component -->
    </div>
    
    </section>
</main>






<script type="text/javascript">

    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        $("#btsearch").click(function(e){
    
            e.preventDefault();

            var employees = $("select[name=employees]").val();
        
            var url = '<?php echo e(url('report/SearchEmployees')); ?>';
    
            $.ajax({
               url:url,
               method:'POST',
               datatype: false,
               data:{
                employees:employees, 
             
                    },
               success:function(response){
              
                $('#tbody').html(response);
                  
               },
               error:function(error){
                  console.log(error)
               }
            });
        });
  

    </script>

<script type="text/javascript">

    /* Load cities into postion <selec> */
  $( "#regions" ).change(function() 
  {
    select = '<option > اختار المدينة</option>'
  $.getJSON("/employee/"+ $(this).val() +"/getCities", function(jsonData){
    $.each(jsonData, function(i,data)
    {
  
         select +='<option value="'+data.id+'">'+data.name+'</option>';
     });
  select += '</select>';
  $("#cities").html(select);
  });
  });
  
      /* Load branches into postion <selec> */
  $( "#cities" ).change(function() 
  {
    select = '<option > اختار الفروع</option>'
  $.getJSON("/employee/"+ $(this).val() +"/getBranche", function(jsonData){
    $.each(jsonData, function(i,data)
    {
  
         select +='<option value="'+data.id+'">'+data.name+'</option>';
     });
  select += '</select>';
  $("#Branches").html(select);
  });
  });
  
  $( "#Branches" ).change(function() 
  {
    select = '<option > اختار اسم المستخدم</option>'
  $.getJSON("/employee/"+ $(this).val() +"/getEmployee", function(jsonData){
    $.each(jsonData, function(i,data)
    {
  
         select +='<option value="'+data.id+'">'+data.name+'</option>';
     });
  select += '</select>';
  $("#employees").html(select);
  });
  });
  </script>
  
    <?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mazin/laravel/convenant/resources/views/report/employee.blade.php ENDPATH**/ ?>