<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<style>
        dialog[open] {
        animation: appear .15s cubic-bezier(0, 1.8, 1, 1.8);
      }
      
        dialog::backdrop {
          background: linear-gradient(45deg, rgba(0, 0, 0, 0.5), rgba(54, 54, 54, 0.5));
          backdrop-filter: blur(3px);
        }
        
       
      @keyframes  appear {
        from {
          opacity: 0;
          transform: translateX(-3rem);
        }
      
        to {
          opacity: 1;
          transform: translateX(0);
        }
      } 
      </style>
<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto sm:mt-10">
    <div class="w-full sm:px-6">

        <?php if(session('status')): ?>
            <div class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    </div>
    <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

            <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <div class="bg-white shadow p-4 flex">
                        <span class="w-auto flex justify-end items-center text-gray-500 p-2">
                            <i class="material-icons text-3xl">     <a href="<?php echo e(route('covenant_create')); ?>" onclick="document.getElementById('myModal').showModal()" id="btn" class="py-3 px-10 bg-gray-800 text-white rounded text shadow-xl"><?php echo e(__('button.add')); ?></a>
                            </i>
                        </span>
                        
                        <input name="search" id="search" class="w-full rounded p-2" type="text" placeholder="<?php echo e(__('button.search')); ?>">
                        <button id="btsearch" class=" btsearch bg-red-400 hover:bg-red-300 rounded text-white p-2 pl-4 pr-4">
                                <p class="font-semibold text-xs"><?php echo e(__('button.search')); ?></p>
                        </button>
                    </div>

                </header>

    
    <div class="w-full p-6">
        <table class="border-collapse w-full">
            <thead>
                <tr>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('header.employee')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('header.rank')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.type')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.serial')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.acceptance')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.code')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('tables.note')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('header.accessory')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('button.edit')); ?></th>
                    <th class="p-3 font-bold uppercase bg-gray-200 text-gray-600 border border-gray-300 hidden lg:table-cell"><?php echo e(__('button.reomve')); ?></th>
            </tr>
            </thead>
            <tbody id="tbody">

                
            <?php $__currentLoopData = $covenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $covenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
                <tr class="bg-white lg:hover:bg-gray-100 flex lg:table-row flex-row lg:flex-row flex-wrap lg:flex-no-wrap mb-10 lg:mb-0">
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->employee->name); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->employee->rank->name); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->ptype->name); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->serial->serial); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->acceptance); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                       <?php echo e($covenant->code_number); ?>

                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b block lg:table-cell relative lg:static">
                            <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase"> name</span>
                           <?php echo e($covenant->note); ?>

                        </td>
                        <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b text-center block lg:table-cell relative lg:static">
                                <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase">Actions</span>
                                <a  href="<?php echo e(route('CovenantAccessory' ,$covenant->id)); ?> " id="btn" class="py-3 px-10 bg-gray-800 text-white rounded text shadow-xl"><?php echo e(__('button.accessory')); ?></a>
                            </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b text-center block lg:table-cell relative lg:static">
                        <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase">Actions</span>
                        <a  onclick="document.getElementById('myModal<?php echo e($covenant->id); ?>').showModal()" id="btn" class="py-3 px-10 bg-gray-800 text-white rounded text shadow-xl"><?php echo e(__('button.edit')); ?></a>
                    </td>
                    <td class="w-full lg:w-auto p-3 text-gray-800 text-center border border-b text-center block lg:table-cell relative lg:static">
                  
                            <span class="lg:hidden absolute top-0 left-0 bg-blue-200 px-2 py-1 text-xs font-bold uppercase">Actions</span>
                 
                        <form action="<?php echo e(route('covenant_destroy',$covenant->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button  class="py-3 px-10 bg-red-800 text-white rounded text shadow-xl" onclick="return confirm('هل انت متاكد من الحذف')">حذف نهاي</button>
                            </form>
                    </td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
        </table>
        <!-- component -->
    </div>
    
    </section>
</main>


<?php $__currentLoopData = $covenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $covenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<dialog id="myModal<?php echo e($covenant->id); ?>" class="h-auto w-11/12 md:w-1/2 p-5  bg-white rounded-md ">
        
    <div class="flex flex-col w-full h-auto ">
         <!-- Header -->
         <div class="flex w-full h-auto justify-center items-center">
           <div class="flex w-10/12 h-auto py-3 justify-center items-center text-2xl font-bold">
           
           </div>
           <div onclick="document.getElementById('myModal<?php echo e($covenant->id); ?>').close();" class="flex w-1/12 h-auto justify-center cursor-pointer">
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
           </div>
           <!--Header End-->
         </div>
           <!-- Modal Content-->
            <div class="flex w-full h-auto py-10 px-2 justify-center items-center bg-gray-200 rounded text-center text-gray-500">
                    <div class="m-7">
         
                            <form action="<?php echo e(route('covenant_update',$covenant->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                            <div class="mb-6">
                                <label for="employees_id" class="block mb-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('header.employee')); ?></label>
                                <input value="<?php echo e($covenant->employees_id); ?>" type="text" name="employees_id" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                                <input value="<?php echo e($covenant->id); ?>" type="hidden" name="id" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                                    </div>
                            
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('tables.type')); ?></label>
                                <input value="<?php echo e($covenant->ptypes_id); ?>" type="text" name="ptypes_id" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                            </div>
                            
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('tables.serial')); ?></label>
                                <input value="<?php echo e($covenant->serials_id); ?>" type="text" name="serials_id" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                            </div>
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('tables.acceptance')); ?></label>
                                <input value="<?php echo e($covenant->acceptance); ?>" type="datetime" name="acceptance" id="acceptance" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                            </div>
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('tables.code')); ?></label>
                                <input value="<?php echo e($covenant->code_number); ?>" type="text" name="code_number" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" />
                            </div>
                            <div class="mb-6">
                                <label for="name" class="block mb-2 text-sm text-gray-600 dark:text-gray-400"><?php echo e(__('tables.note')); ?></label>
                                <textarea  type="text" name="note" id="name" placeholder="John Doe" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-100 focus:border-indigo-300 dark:bg-gray-700 dark:text-white dark:placeholder-gray-500 dark:border-gray-600 dark:focus:ring-gray-900 dark:focus:border-gray-500" >
                                        <?php echo e($covenant->note); ?>

                                </textarea>
                            </div>
                            <div class="mb-6">
                                <button type="submit" class=" btn-submit w-full px-3 py-4 text-white bg-indigo-500 rounded-md focus:bg-indigo-600 focus:outline-none"><?php echo e(__('button.edit')); ?></button>
                            </div>
                            <p class="text-base text-center text-gray-400" id="result">
                            </p>
                            </form>
                    </div>
           </div>
           <!-- End of Modal Content-->
           
           
           
         </div>
 </dialog>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 


<script type="text/javascript">

    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
    
        $(".btn-insert").click(function(e){
    
            e.preventDefault();
    
            var namef = $("input[name=nameinsert]").val();
            var url = '<?php echo e(url('job/store')); ?>';
    
            $.ajax({
               url:url,
               method:'POST',
               data:{
                nameinsert:namef, 
                processData: false,
                        contentType: false,
                    },
               success:function(response){
                  if(response.success){
                    document.getElementById('myModal').close()
                      alert(response.message) //Message come from controller
                  }else{
                      alert("Error")
                  }
               },
               error:function(error){
                  console.log(error)
               }
            });
        });
    
    </script>


<script type="text/javascript">

    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    
        $(".btsearch").click(function(e){
    
            e.preventDefault();
    
            var SearchEmployee = $("input[name=search]").val();
            var url = '<?php echo e(url('covenant/SearchEmployee')); ?>';
    
            $.ajax({
               url:url,
               method:'POST',
               datatype: false,
               data:{
                SearchEmployee:SearchEmployee, 
                    },
               success:function(response){
                   console.log(response)
               
                $('#tbody').html(response);
                  
               },
               error:function(error){
                  console.log(error)
               }
            });
        });
  

    </script>

    
    <?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mazin/laravel/convenant/resources/views/covenant/index.blade.php ENDPATH**/ ?>